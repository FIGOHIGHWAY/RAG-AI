import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class FileService {
  private http = inject(HttpClient);

  readTextFile(filePath: string) {
    return this.http.get(filePath, { responseType: 'text' });
  }
}

import {
  Component,
  computed,
  ElementRef,
  inject,
  model,
  OnInit,
  signal,
  viewChild,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { firstValueFrom } from 'rxjs';

import { StringOutputParser } from '@langchain/core/output_parsers';
import { ChatPromptTemplate } from '@langchain/core/prompts';
import { SupabaseVectorStore } from '@langchain/community/vectorstores/supabase';

import { Ollama, OllamaEmbeddings } from '@langchain/ollama';
import { createClient } from '@supabase/supabase-js';

import { Document } from '@langchain/core/documents';

import {
  EMBEDDING_MODEL_NAME,
  FILE_PATH,
  MODEL_NAME,
  PROMPT_TEMPLATE,
  SUPABASE_PRIVATE_KEY,
  SUPABASE_URL,
} from './const';

import { FileService } from './services/file.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  imports: [FormsModule],
})
export class AppComponent implements OnInit {
  fileService = inject(FileService);

  chatListRef = viewChild<ElementRef<HTMLElement>>('chatListRef');

  llm: Ollama = new Ollama({
    model: MODEL_NAME,
    temperature: 0.8,
  });
  embeddings: OllamaEmbeddings = new OllamaEmbeddings({
    model: EMBEDDING_MODEL_NAME,
  });

  prompt: ChatPromptTemplate = ChatPromptTemplate.fromTemplate(PROMPT_TEMPLATE);
  outputParser: StringOutputParser = new StringOutputParser();

  supabaseClient = createClient(SUPABASE_URL, SUPABASE_PRIVATE_KEY);

  vectorStore = new SupabaseVectorStore(this.embeddings, {
    client: this.supabaseClient,
    tableName: 'documents',
    queryName: 'match_documents',
  });

  result = signal<string>('Thinking...');
  resultList = signal<string[]>([]);

  userInput = model<string>();

  fileContentList = signal<string[]>([]);
  documents = signal<Document[]>([]);

  ids = computed(() => this.documents().map((_, index) => index));

  loading = signal<boolean>(false);

  async ngOnInit() {
    await this.readTextFromFile(FILE_PATH);
    this.textToDocuments();
    this.saveToVectorDB();
  }

  onSend() {
    this.callLLM();
  }

  async callLLM() {
    if (!this.userInput() || this.userInput() == '') return;

    this.resultList.update((v) => [...v, this.userInput() || '']);

    this.result.set('Thinking...');
    this.loading.set(true);

    const question = this.userInput()?.toString();

    this.userInput.set('');

    this.scrollToBottom();

    const chain = this.prompt.pipe(this.llm).pipe(this.outputParser);

    const retriever = this.vectorStore.asRetriever(3);
    const informations = await retriever.invoke(question || '');

    const stream = await chain.stream({
      informations: informations,
      question: question,
    });

    try {
      this.result.set('');

      for await (const chunk of stream) {
        if (chunk !== '\n') {
          this.result.update((str) => (str += chunk));
        } else {
          this.result.update((str) => (str += '<br/>'));
        }

        this.scrollToBottom();
      }

      console.log('Stream processing complete.');

      this.loading.set(false);

      this.resultList.update((v) => [...v, this.result()]);
    } catch (error) {
      console.error('Error processing stream:', error);
    }
  }

  async saveToVectorDB() {
    await this.vectorStore.addDocuments(this.documents(), { ids: this.ids() });
  }

  async readTextFromFile(filePath: string) {
    try {
      const fileContent = await firstValueFrom(
        this.fileService.readTextFile(filePath),
        { defaultValue: '' }
      );

      this.fileContentList.set(fileContent.split('\n'));
    } catch (err) {
      console.error('Read file error: ', err);
    }
  }

  textToDocuments() {
    this.fileContentList().forEach((text, index) => {
      if (text == '') return;

      const document: Document = {
        pageContent: text,
        metadata: { filePath: FILE_PATH, id: index },
      };

      this.documents.update((v) => [...v, document]);
    });
  }

  scrollToBottom(): void {
    try {
      this.chatListRef()!.nativeElement.scrollTop =
        this.chatListRef()!.nativeElement.scrollHeight;
    } catch (err) {}
  }
}

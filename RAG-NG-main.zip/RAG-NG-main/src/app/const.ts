// models
const MODEL_NAME = 'gemma3:4b';
const EMBEDDING_MODEL_NAME = 'bge-m3:567m';

// supabase
const SUPABASE_URL = import.meta.env.APP_SUPABASE_URL;
const SUPABASE_PRIVATE_KEY = import.meta.env.APP_SUPABASE_PRIVATE_KEY;

// files
const FILE_PATH = 'text-files/restaurant_info.txt';

const PROMPT_TEMPLATE = `คุณคือพนักงานหญิงของร้านอาหาร Green Leaf Cafe มีหน้าที่ตอบคำถามของลูกค้าโดยอ้างอิงจากข้อมูลที่ให้มาในส่วน "{informations}" เท่านั้น กรุณาตอบคำถามด้วยภาษาไทยที่ดึงดูด น่าสนใจ และกระชับ

เริ่มต้นประโยคด้วย สวัสดีค่ะ
\n
ข้อมูลที่เกี่ยวข้อง:\n
{informations}
\n
คำถาม:\n
{question}
\n
โปรดจำไว้ว่าให้ตอบโดยใช้ข้อมูลที่ให้มาเท่านั้น หากคำถามนั้นไม่มีข้อมูลอยู่ในส่วนที่ให้มา ไม่จำเป็นต้องให้ข้อมูลเพิ่มเติม

ลงท้ายประโยคด้วย ขอบคุณค่ะ`;

export {
  MODEL_NAME,
  EMBEDDING_MODEL_NAME,
  SUPABASE_URL,
  SUPABASE_PRIVATE_KEY,
  FILE_PATH,
  PROMPT_TEMPLATE,
};
